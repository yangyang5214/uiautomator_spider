# -*- coding: UTF-8 -*-


import uiautomator2 as u2


def get_all_text(app, xpath=None):
    if not xpath:
        xpath = '//android.widget.TextView'
    return [_.text.strip() for _ in app.xpath(xpath).all() if _.text.strip()]


if __name__ == '__main__':
    app = u2.connect()

    app.swipe(300, 800, 300, 400, 0.1)
